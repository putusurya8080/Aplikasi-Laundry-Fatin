﻿Imports System.Data.OleDb
Public Class FormLogin
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Rd As OleDbDataReader
    Dim Cmd As OleDbCommand
    Dim LokasiDB As String
    Sub Koneksi()
        LokasiDB = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_laundry.accdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub
    Sub PESAN()
        ProgressBar1.Value = 100

        If TextBox1.Text = "ADM001" And TextBox2.Text = "ADMIN" Then

            MsgBox("Login Berhasil Selamat Datang", vbInformation)
        Else
            If TextBox1.Text = "ADM002" And TextBox2.Text = "USER" Then

                MsgBox("Login Berhasil Selamat Datang", vbInformation)
            Else
                'MsgBox("Login Gagal,Coba lagi", vbInformation)
                'ProgressBar1.Value = 90
                Exit Sub
            End If
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then

            MsgBox("Kode Admin dan Password Tidak Boleh Kosong!")
        Else
            Call PESAN()
            Call Koneksi()

            Cmd = New OleDbCommand("Select * From tbl_admin where kode_admin ='" & TextBox1.Text & "' and password_admin = '" & TextBox2.Text & "' and password_admin = '" & TextBox2.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                Me.Close()
                Call Terbuka()
                FormMENU_UTAMA.STLabel2.Text = Rd!Kode_Admin
                FormMENU_UTAMA.STLabel4.Text = Rd!Nama_Admin
                FormMENU_UTAMA.STLabel6.Text = Rd!Level_Admin
                animaten(Me, False)

                If FormMENU_UTAMA.STLabel6.Text = "USER" Then
                    FormMENU_UTAMA.DATAADMINToolStripMenuItem.Enabled = False

                End If

            Else

                MsgBox("Kode_admin atau password salah!")
            End If
            Exit Sub
        End If
    End Sub
    Sub Terbuka()
        FormMENU_UTAMA.LOGINToolStripMenuItem.Enabled = False
        FormMENU_UTAMA.LOGOUTToolStripMenuItem.Enabled = True
        FormMENU_UTAMA.MASTERToolStripMenuItem.Enabled = True
        FormMENU_UTAMA.TRANSAKSIToolStripMenuItem.Enabled = True
        FormMENU_UTAMA.LAPORANToolStripMenuItem.Enabled = True
        FormMENU_UTAMA.UTILITYToolStripMenuItem.Enabled = True
       
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
    End Sub
    Sub KondisiAwal()
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub FormLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call KondisiAwal()
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            TextBox2.Focus()
        End If
    End Sub

    Private Sub TextBox2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(13) Then
            Button1.Focus()
        End If
    End Sub
End Class