﻿Imports System.Data.OleDb
Imports System.Drawing.Printing
Public Class FormPENGEMBALIAN
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Rd As OleDbDataReader
    Dim Cmd As OleDbCommand
    Dim LokasiDB As String

    Dim WithEvents PD As New PrintDocument
    Dim WithEvents PD2 As New PrintDocument
    Dim PPD As New PrintPreviewDialog
    Dim PPD2 As New PrintPreviewDialog
    Dim harga As Integer
    Dim dp As Integer
    Dim ss As Integer
    Dim TglMyOdbc As String
    Sub Koneksi()
        LokasiDB = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_laundry.accdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub
    Private Sub FormPENGEMBALIAN_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        animaten(Me, True)
        Call kondisiAwal()
    End Sub
    Sub MunculKeterangan()
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_Transaksi", Conn)
        Rd = Cmd.ExecuteReader
        Do While Rd.Read
            keterangan.Items.Clear()
            keterangan.Items.Add(Rd.Item(12))
        Loop
    End Sub
    Sub MunculKodePelanggan()
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_pelanggan", Conn)
        Rd = Cmd.ExecuteReader
        Do While Rd.Read
            nota.Items.Clear()
            nota.Items.Add(Rd.Item(1))
        Loop
    End Sub
   Sub kondisiAwal()
        no_transaksi.Text = ""
        kode_pelanggan.Text = ""
        nota.Text = ""
        nama_pelanggan.Text = ""
        alamat.Text = ""
        telepon.Text = ""
        tanggal.Text = ""
        Admin.Text = ""   
        Tgl_ambil.Text = ""
        total.Text = ""
        bayar.Text = ""
        sisa.Text = ""
        keterangan.Text = ""

        kode_pelanggan.BackColor = Color.Aqua
        nota.BackColor = Color.Aqua
        nama_pelanggan.BackColor = Color.Aqua
        alamat.BackColor = Color.Aqua
        telepon.BackColor = Color.Aqua
        tanggal.BackColor = Color.Aqua
        no_transaksi.BackColor = Color.Aqua
        Admin.BackColor = Color.Aqua
        keterangan.BackColor = Color.Aqua
        Tgl_ambil.BackColor = Color.Aqua
        total.BackColor = Color.Aqua
        bayar.BackColor = Color.Aqua
        sisa.BackColor = Color.Aqua

        kode_pelanggan.Enabled = False
        nama_pelanggan.Enabled = False
        alamat.Enabled = False
        telepon.Enabled = False
        tanggal.Enabled = False
        no_transaksi.Enabled = False
        Admin.Enabled = False
        total.Enabled = False
        bayar.Enabled = False
        sisa.Enabled = False
        Tgl_ambil.Enabled = False
        Call MunculKeterangan()
        Call MunculKodePelanggan()
        DataGridView1.Columns.Clear()
        DataGridView1.Refresh()
    End Sub
    Sub SiapIsi()
        total.Enabled = True
        bayar.Enabled = True
        sisa.Enabled = True

        kode_pelanggan.BackColor = Color.Black
        nota.BackColor = Color.Black
        nama_pelanggan.BackColor = Color.Black
        alamat.BackColor = Color.Black
        telepon.BackColor = Color.Black
        tanggal.BackColor = Color.Black
        no_transaksi.BackColor = Color.Black
        Admin.BackColor = Color.Black
        keterangan.BackColor = Color.Black
        Tgl_ambil.BackColor = Color.Black

        total.BackColor = Color.Black
        bayar.BackColor = Color.Black
        sisa.BackColor = Color.Black

        kode_pelanggan.Enabled = True
        nama_pelanggan.Enabled = True
        alamat.Enabled = True
        telepon.Enabled = True
        tanggal.Enabled = True
        no_transaksi.Enabled = True
        Admin.Enabled = True
        total.Enabled = True
        bayar.Enabled = True
        sisa.Enabled = True
        Tgl_ambil.Enabled = True

    End Sub

    Private Sub nota_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles nota.KeyPress
        Call Koneksi()
        Cmd = New OleDbCommand("select * from tbl_transaksi where nota='" & nota.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            tanggal.Text = Rd.Item("tanggal_masuk")
            Tgl_ambil.Text = Rd.Item("tanggal_ambil")
            no_transaksi.Text = Rd.Item("no_transaksi")
            keterangan.Text = Rd.Item("keterangan")
            Admin.Text = Rd.Item("admin")
            kode_pelanggan.Text = Rd.Item("KODE_pelanggan")
            total.Text = Rd.Item("Harga_Total")
            bayar.Text = Rd.Item("bayar")
            sisa.Text = Rd.Item("SISA")

            Call Koneksi()
            Cmd = New OleDbCommand("select nama_pelanggan from tbl_pelanggan where nota='" & nota.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                nama_pelanggan.Text = Rd.Item("nama_pelanggan")

                Koneksi()
                Cmd = New OleDbCommand("select telepon from TBL_pelanggan where nota='" & nota.Text & "'", Conn)
                Rd = Cmd.ExecuteReader
                Rd.Read()
                If Rd.HasRows Then
                    telepon.Text = Rd.Item("telepon")

                    Koneksi()
                    Cmd = New OleDbCommand("select alamat from TBL_pelanggan where NOTA='" & nota.Text & "'", Conn)
                    Rd = Cmd.ExecuteReader
                    Rd.Read()
                    If Rd.HasRows Then
                        alamat.Text = Rd.Item("alamat")
                        Call Returan()

                    End If
                End If
            End If
        End If

    End Sub

    Private Sub nota_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nota.SelectedIndexChanged
        Call Koneksi()
        Cmd = New OleDbCommand("select * from tbl_transaksi where nota='" & nota.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            tanggal.Text = Rd.Item("tanggal_masuk")
            Tgl_ambil.Text = Rd.Item("tanggal_ambil")
            no_transaksi.Text = Rd.Item("no_transaksi")
            keterangan.Text = Rd.Item("keterangan")
            Admin.Text = Rd.Item("admin")
            kode_pelanggan.Text = Rd.Item("KODE_pelanggan")
            total.Text = Rd.Item("Harga_Total")
            bayar.Text = Rd.Item("bayar")
            sisa.Text = Rd.Item("SISA")

            Call Koneksi()
            Cmd = New OleDbCommand("select nama_pelanggan from tbl_pelanggan where nota='" & nota.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                nama_pelanggan.Text = Rd.Item("nama_pelanggan")

                Koneksi()
                Cmd = New OleDbCommand("select telepon from TBL_pelanggan where nota='" & nota.Text & "'", Conn)
                Rd = Cmd.ExecuteReader
                Rd.Read()
                If Rd.HasRows Then
                    telepon.Text = Rd.Item("telepon")

                    Koneksi()
                    Cmd = New OleDbCommand("select alamat from TBL_pelanggan where NOTA='" & nota.Text & "'", Conn)
                    Rd = Cmd.ExecuteReader
                    Rd.Read()
                    If Rd.HasRows Then
                        alamat.Text = Rd.Item("alamat")
                        Call Returan()

                    End If
                End If
            End If
        End If

    End Sub
    Sub Returan()
        Call Koneksi()
        Da = New OleDbDataAdapter("select tbl_barang.kode_barang,tbl_barang.nama_barang,detail_transaksi.harga,detail_transaksi.satuan,detail_transaksi.QTY,detail_transaksi.Subtotal from tbl_pelanggan,tbl_transaksi,tbl_barang,detail_transaksi where tbl_barang.kode_barang = detail_transaksi.kode_barang and tbl_transaksi.no_transaksi = detail_transaksi.no_transaksi and tbl_pelanggan.nota= tbl_transaksi.nota and tbl_pelanggan.nota = '" & nota.Text & "' and detail_transaksi.QTY > 0", Conn)
        Ds = New DataSet
        Ds.Clear()
        Da.Fill(Ds, "detail_transaksi")
        DataGridView1.DataSource = Ds.Tables("detail_transaksi")
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 300
        DataGridView1.Columns(2).Width = 150
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).Width = 50
        DataGridView1.Columns(5).Width = 300
        DataGridView1.ReadOnly = True
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Call Koneksi()
        TglMyOdbc = Format(Today, "yyyy-MM-dd")
        Dim Simpanjual As String = "insert into tbl_ambil values('" & no_transaksi.Text & "','" & tanggal.Text & "','" & Tgl_ambil.Text & "','" & kode_pelanggan.Text & "','" & nota.Text & "','" & nama_pelanggan.Text & "','" & alamat.Text & "','" & telepon.Text & "','" & total.Text & "','" & bayar.Text & "','" & sisa.Text & "','" & Admin.Text & "','" & keterangan.Text & "') "
        Cmd = New OleDbCommand(Simpanjual, Conn)
        Cmd.ExecuteNonQuery()

        For Baris As Integer = 0 To DataGridView1.Rows.Count - 2
            Call Koneksi()
            TglMyOdbc = Format(Today, "yyyy-MM-dd")
            Dim SimpanDetail As String = "insert into detail_ambil values('" & no_transaksi.Text & "','" & DataGridView1.Rows(Baris).Cells(0).Value & "','" & DataGridView1.Rows(Baris).Cells(1).Value & "','" & DataGridView1.Rows(Baris).Cells(4).Value & "','" & DataGridView1.Rows(Baris).Cells(3).Value & "','" & DataGridView1.Rows(Baris).Cells(2).Value & "','" & DataGridView1.Rows(Baris).Cells(5).Value & "')"
            Cmd = New OleDbCommand(SimpanDetail, Conn)
            Cmd.ExecuteNonQuery()

            Call Koneksi()
            Cmd = New OleDbCommand("select * from tbl_barang where kode_barang = '" & DataGridView1.Rows(Baris).Cells(0).Value & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            Call Koneksi()
            Dim KurangiStok2 As String = "Update TBL_barang set QTY = '" & Rd.Item("QTY") - DataGridView1.Rows(Baris).Cells(4).Value & "' where Kode_Barang='" & DataGridView1.Rows(Baris).Cells(0).Value & "'"
            Cmd = New OleDbCommand(KurangiStok2, Conn)
            Cmd.ExecuteNonQuery()
        Next      
        PPD.Document = PD
        PPD.ShowDialog()
        MsgBox("Transaksi Berhasil di Simpan")
        Call hapusdata()
        Call kondisiAwal()
    End Sub
    Sub hapusdata()
        Call Koneksi()
        Dim HapusData As String = "Delete from tbl_transaksi where no_transaksi='" & no_transaksi.Text & "'"
        Cmd = New OleDbCommand(HapusData, Conn)
        Cmd.ExecuteNonQuery()
        'MsgBox("Data Berhasil di Hapus")
        Call Koneksi()
        Dim HapusData2 As String = "Delete from detail_transaksi where no_transaksi='" & no_transaksi.Text & "'"
        Cmd = New OleDbCommand(HapusData2, Conn)
        Cmd.ExecuteNonQuery()
        MsgBox("Data Berhasil di Proses")
    End Sub
    Dim I As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        I = I + 1
        If I = 2 Then
            I = 0
        End If
        If I Mod 2 = 0 Then
            Label11.Visible = True
            Label12.Visible = False
        Else
            Label11.Visible = False
            Label12.Visible = True
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Call SiapIsi()
       
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Call kondisiAwal()
    End Sub

    Private Sub bayar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles bayar.KeyPress
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9" Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
        If e.KeyChar = Chr(13) Then
            sisa.Text = Val(total.Text) - Val(bayar.Text)
            Button1.Focus()
        End If
    End Sub

    Private Sub PD_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PD.BeginPrint
        Dim pagesetup As New PageSettings
        pagesetup.PaperSize = New PaperSize("Custom", 200, 350)
        PD.DefaultPageSettings = pagesetup
    End Sub

    Private Sub PD_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PD.PrintPage
        Dim f10 As New Font("Times New Roman", 10, FontStyle.Regular)
        Dim f10b As New Font("Times New Roman", 10, FontStyle.Bold)
        Dim f14 As New Font("Times New Roman", 14, FontStyle.Bold)
        Dim f8 As New Font("Times New Roman", 8, FontStyle.Regular)
        Dim f6 As New Font("Times New Roman", 6, FontStyle.Regular)

        Dim leftmargin As Integer = PD.DefaultPageSettings.Margins.Left
        Dim centermargin As Integer = PD.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = PD.DefaultPageSettings.PaperSize.Width

        Dim kanan As New StringFormat
        Dim tengah As New StringFormat
        kanan.Alignment = StringAlignment.Far
        tengah.Alignment = StringAlignment.Center

        Dim garis As String
        garis = ".................................................................................................................................."
        Dim TopRight As StringFormat = New StringFormat()
        TopRight.LineAlignment = StringAlignment.Near
        TopRight.Alignment = StringAlignment.Far

        e.Graphics.DrawString("NOTA TRANSAKSI", f8, Brushes.Red, centermargin, 5, tengah)
        e.Graphics.DrawString("BUKIT LAUNDRY INDONESIA", f8, Brushes.Blue, centermargin, 18, tengah)
        e.Graphics.DrawString("TLP : 031-8889801", f8, Brushes.Black, centermargin, 30, tengah)
        e.Graphics.DrawString(garis, f8, Brushes.DarkRed, 0, 40)

        e.Graphics.DrawString("Nama Cst  : ", f8, Brushes.Black, 10, 50)
        e.Graphics.DrawString(nama_pelanggan.Text, f8, Brushes.Purple, 70, 50)

        e.Graphics.DrawString("Nota :", f8, Brushes.Black, 130, 50)
        e.Graphics.DrawString(nota.Text, f8, Brushes.Purple, 160, 50)

        e.Graphics.DrawString("Telepon : ", f8, Brushes.Black, 10, 60)
        e.Graphics.DrawString(telepon.Text, f8, Brushes.Purple, 70, 60)

        e.Graphics.DrawString("Tgl Masuk : ", f8, Brushes.Black, 10, 70)
        e.Graphics.DrawString(tanggal.Text, f8, Brushes.Purple, 70, 70)

        e.Graphics.DrawString("Tgl Ambil : ", f8, Brushes.Black, 10, 80)
        e.Graphics.DrawString(Tgl_ambil.Text, f8, Brushes.Purple, 70, 80)

        e.Graphics.DrawString("Nama Barang", f8, Brushes.Red, 10, 95)
        e.Graphics.DrawString("Qty", f8, Brushes.Red, 110, 95)
        e.Graphics.DrawString("Subtotal", f8, Brushes.Red, 147, 95)
        e.Graphics.DrawString(garis, f8, Brushes.DarkRed, 0, 100)

        DataGridView1.AllowUserToAddRows = False
        Dim Tinggi As Integer
        For baris As Integer = 0 To DataGridView1.RowCount - 1
            Tinggi += 15
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(1).Value.ToString, f6, Brushes.Black, 10, 100 + Tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(4).Value.ToString, f6, Brushes.Black, 120, 100 + Tinggi)
            e.Graphics.DrawString(Format(DataGridView1.Rows(baris).Cells(5).Value, "##,##0"), f6, Brushes.Black, 160, 100 + Tinggi)
        Next
        Tinggi = 100 + Tinggi
        jumlahsubtotal()
        e.Graphics.DrawString(garis, f10, Brushes.Black, 0, Tinggi)

        e.Graphics.DrawString("Total   " & Format(harga, "##,##0"), f8, Brushes.Black, 200, 15 + Tinggi, kanan)

        e.Graphics.DrawString("Bayar ", f8, Brushes.Black, 160, 30 + Tinggi, kanan)
        e.Graphics.DrawString(bayar.Text, f8, Brushes.Black, 200, 30 + Tinggi, kanan)

        e.Graphics.DrawString("Sisa ", f8, Brushes.Black, 160, 45 + Tinggi, kanan)
        e.Graphics.DrawString(sisa.Text, f8, Brushes.Black, 200, 45 + Tinggi, kanan)

        e.Graphics.DrawString("~~~~ Terima Kasih ~~~~", f8, Brushes.Blue, centermargin, 250, tengah)

    End Sub
    Sub jumlahsubtotal()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DataGridView1.RowCount - 1
            hitung = hitung + DataGridView1.Rows(baris).Cells(5).Value
        Next
        harga = hitung
    End Sub

    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label13.Click
        animaten(Me, False)
        Me.Close()
    End Sub
End Class