﻿Imports System.Data.OleDb
Public Class FormDaftar_Transaksi
    Dim i As Integer
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Rd As OleDbDataReader
    Dim Cmd As OleDbCommand
    Dim LokasiDB As String
    Dim TglMyOdbc As String
    Sub Koneksi()
        LokasiDB = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_laundry.accdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        i = i + 1
        If i = 2 Then
            i = 0
        End If
        If i Mod 2 = 0 Then
            Label1.Visible = True
            Label2.Visible = False
        Else
            Label1.Visible = False
            Label2.Visible = True
        End If
    End Sub
  Private Sub FormDaftar_Transaksi_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BUATKOLOM()
    End Sub
    Sub BUATKOLOM()
        Call Koneksi()
        Da = New OleDbDataAdapter("select * From tbl_transaksi where nota like '%" & TextBox1.Text & "%'", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        DataGridView1.ReadOnly = True
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 110
        DataGridView1.Columns(2).Width = 110
        DataGridView1.Columns(3).Width = 120
        DataGridView1.Columns(4).Width = 60
        DataGridView1.Columns(5).Width = 130
        DataGridView1.Columns(6).Width = 250
        DataGridView1.Columns(7).Width = 150
        DataGridView1.Columns(8).Width = 100
        DataGridView1.Columns(9).Width = 100
        DataGridView1.Columns(10).Width = 100
        DataGridView1.Columns(11).Width = 100
        DataGridView1.Columns(12).Width = 150

        DataGridView1.Columns(8).DefaultCellStyle.Format = "#,###"
        DataGridView1.Columns(9).DefaultCellStyle.Format = "#,###"
        DataGridView1.Columns(10).DefaultCellStyle.Format = "#,###"
        DataGridView1.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 9)
        DataGridView1.DefaultCellStyle.ForeColor = Color.Brown
        'DataGridView1.DefaultCellStyle.BackColor = Color.Aquamarine
        'DataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite
      
    End Sub
    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        'Call Koneksi()
        'Cmd = New OleDbCommand("select * From tbl_transaksi where nota like '%" & TextBox1.Text & "%'", Conn)
        'Rd = Cmd.ExecuteReader
        'Rd.Read()
        'If Rd.HasRows Then
        Call Koneksi()
        Da = New OleDbDataAdapter("select * From tbl_transaksi where nota like '%" & TextBox1.Text & "%'", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DataGridView1.DataSource = Ds.Tables(0)
        DataGridView1.ReadOnly = True
        If TextBox1.Text = "" Then
            Label3.Visible = True
        Else
            Label3.Visible = False
        End If
        'End If
    End Sub
End Class