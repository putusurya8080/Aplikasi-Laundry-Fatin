﻿Imports System.Data.OleDb
Imports System.Drawing.Printing
Public Class FormTRANSAKSI
    Dim Conn As OleDbConnection
    Dim Da As OleDbDataAdapter
    Dim Ds As DataSet
    Dim Rd As OleDbDataReader
    Dim Cmd As OleDbCommand
    Dim LokasiDB As String

    Dim WithEvents PD As New PrintDocument
    Dim WithEvents PD2 As New PrintDocument
    Dim PPD As New PrintPreviewDialog
    Dim PPD2 As New PrintPreviewDialog
    Dim harga As Integer
    Dim dp As Integer
    Dim ss As Integer
    Dim TglMyOdbc As String
    Sub Koneksi()
        LokasiDB = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=db_laundry.accdb"
        Conn = New OleDbConnection(LokasiDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub
    Private Sub FormTRANSAKSI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        animaten(Me, True)
        Call kondisiAwal()
    End Sub
    Sub MunculKeterangan()
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_Transaksi", Conn)
        Rd = Cmd.ExecuteReader
        Do While Rd.Read
            'keterangan.Items.Clear()
            keterangan.Items.Add(Rd.Item(12))
        Loop
    End Sub
    Sub MunculKodePelanggan()
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_pelanggan", Conn)
        Rd = Cmd.ExecuteReader
        Do While Rd.Read
            nota.Items.Clear()
            nota.Items.Add(Rd.Item(1))
        Loop
    End Sub
    Sub NomorOtomatis()
        Call Koneksi()
        Cmd = New OleDbCommand("select * From TBL_TRANSAKSI where no_transaksi in (select max(no_transaksi) from TBL_TRANSAKSI)", Conn)
        Dim UrutanKode As String
        Dim Hitung As Long
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Not Rd.HasRows Then
            UrutanKode = "TR" + Format(Now, "yymmdd") + "001"
        Else
            Hitung = Microsoft.VisualBasic.Right(Rd.GetString(0), 9) + 1
            UrutanKode = "TR" + Format(Now, "yymmdd") + Microsoft.VisualBasic.Right("000" & Hitung, 3)
        End If
        no_transaksi.Text = UrutanKode
    End Sub
    Sub kondisiAwal()
        kode_pelanggan.Text = ""
        nota.Text = ""
        nama_pelanggan.Text = ""
        alamat.Text = ""
        telepon.Text = ""
        tanggal.Text = Today
        Admin.Text = FormMENU_UTAMA.STLabel4.Text
        jam.Text = Format(TimeOfDay, "HH:mm:ss")

        total.Text = ""
        bayar.Text = ""
        sisa.Text = ""
        keterangan.Text = ""
        TextBox1.Text = ""

        kode_pelanggan.BackColor = Color.Aqua
        nota.BackColor = Color.Aqua
        nama_pelanggan.BackColor = Color.Aqua
        alamat.BackColor = Color.Aqua
        telepon.BackColor = Color.Aqua
        tanggal.BackColor = Color.Aqua
        jam.BackColor = Color.Aqua
        no_transaksi.BackColor = Color.Aqua
        Admin.BackColor = Color.Aqua
        keterangan.BackColor = Color.Aqua

        kode_pelanggan.Enabled = False
        nama_pelanggan.Enabled = False
        alamat.Enabled = False
        telepon.Enabled = False
        tanggal.Enabled = False
        jam.Enabled = False
        no_transaksi.Enabled = False
        Admin.Enabled = False
        total.Enabled = False
        bayar.Enabled = False
        sisa.Enabled = False
        Call NomorOtomatis()
        Call MunculKeterangan()
        Call MunculKodePelanggan()
        Call BuatKolom()
        Call TampilBarang()

    End Sub

    Sub siapIsi()
        kode_pelanggan.Enabled = False
        nota.Enabled = True
        tanggal.Enabled = False
        jam.Enabled = False
        no_transaksi.Enabled = False
        Admin.Enabled = False
        total.Enabled = True
        bayar.Enabled = True
        sisa.Enabled = True
        keterangan.Enabled = True
        Button1.Enabled = True
        nota.BackColor = Color.White
        keterangan.BackColor = Color.White
    End Sub

    Sub BuatKolom()
        DataGridView1.Columns.Clear()
        DataGridView1.Columns.Add("Kode", "Kode Barang")
        DataGridView1.Columns.Add("Nama", "Nama Barang")
        DataGridView1.Columns.Add("Harga", "Harga")
        DataGridView1.Columns.Add("Satuan", "Satuan")
        DataGridView1.Columns.Add("Jumlah", "Qty")
        DataGridView1.Columns.Add("SubTotal", "SubTotal")

        DataGridView1.Columns(0).Width = 90
        DataGridView1.Columns(1).Width = 250
        DataGridView1.Columns(2).Width = 80
        DataGridView1.Columns(3).Width = 80
        DataGridView1.Columns(4).Width = 50
        DataGridView1.Columns(5).Width = 150

        DataGridView1.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10)
        DataGridView1.Columns(5).DefaultCellStyle.Format = "#,###"
        DataGridView1.Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        DataGridView1.DefaultCellStyle.BackColor = Color.Silver
        DataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite

    End Sub
    Sub TampilBarang()
        Call Koneksi()
        Da = New OleDbDataAdapter("Select * from TBL_barang", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "TBL_barang")
        DGV2.DataSource = Ds.Tables("TBL_barang")
        DGV2.ReadOnly = True
        DGV2.Columns(0).Width = 70
        DGV2.Columns(1).Width = 275
        DGV2.Columns(2).Width = 75
        DGV2.Columns(3).Width = 100
        DGV2.Columns(4).Width = 100
     
        Call Koneksi()
        Da = New OleDbDataAdapter("select * from tbl_barang", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DGV2.DataSource = Ds.Tables(0)
        DGV2.ReadOnly = True

        DGV2.DefaultCellStyle.Font = New Font("Microsoft Sans Serif", 10)
        DGV2.DefaultCellStyle.ForeColor = Color.Black
        DGV2.DefaultCellStyle.BackColor = Color.Aquamarine
        DGV2.AlternatingRowsDefaultCellStyle.BackColor = Color.AntiqueWhite
    End Sub
    Private Sub nota_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles nota.KeyPress
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_PELANGGAN where nota='" & nota.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Not Rd.HasRows Then
            'MsgBox("Nomor Nota Dan Nama Customer tidak Di temukan...!!!")
        Else
            kode_pelanggan.Text = Rd!kode_Pelanggan
            nama_pelanggan.Text = Rd!Nama_Pelanggan
            alamat.Text = Rd!Alamat
            telepon.Text = Rd!Telepon
            nota.Text = Rd!nota
        End If
    End Sub
    Private Sub nota_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nota.SelectedIndexChanged
        Call Koneksi()
        Cmd = New OleDbCommand("select * from TBL_PELANGGAN where nota='" & nota.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Not Rd.HasRows Then
            MsgBox("Nomor Nota Dan Nama Customer tidak Di temukan...!!!")
        Else
            kode_pelanggan.Text = Rd!kode_Pelanggan
            nama_pelanggan.Text = Rd!Nama_Pelanggan
            alamat.Text = Rd!Alamat
            telepon.Text = Rd!Telepon
            nota.Text = Rd!nota
        End If
    End Sub
    Private Sub DataGridView1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles DataGridView1.KeyPress
        On Error Resume Next
        If e.KeyChar = Chr(27) Then
            DataGridView1.Rows.Remove(DataGridView1.CurrentRow)
            Call RumusSubTotal()
        End If
    End Sub
    Private Sub DataGridView1_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellEndEdit
        If e.ColumnIndex = 4 Then
            Try
                DataGridView1.Rows(e.RowIndex).Cells(5).Value = DataGridView1.Rows(e.RowIndex).Cells(2).Value * DataGridView1.Rows(e.RowIndex).Cells(4).Value

            Catch ex As Exception
                MsgBox("Harus Di isi Dengan Angka Gaes..!!!")
                SendKeys.Send("{UP}")
                DataGridView1.Rows(e.RowIndex).Cells(4).Value = 1
                DataGridView1.Rows(e.RowIndex).Cells(5).Value = DataGridView1.Rows(e.RowIndex).Cells(2).Value * DataGridView1.Rows(e.RowIndex).Cells(4).Value
            End Try
        End If
        Call RumusSubTotal()
    End Sub
    Sub RumusSubTotal()
        Dim Hitung As Integer = 0
        For i As Integer = 0 To DataGridView1.Rows.Count - 1
            Hitung = Hitung + DataGridView1.Rows(i).Cells(5).Value
            total.Text = Hitung      
        Next
    End Sub
    Private Sub DGV2_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV2.CellMouseClick
        On Error Resume Next
        DataGridView1.Rows.Add(DGV2.Rows(e.RowIndex).Cells(0).Value, DGV2.Rows(e.RowIndex).Cells(1).Value, DGV2.Rows(e.RowIndex).Cells(4).Value, DGV2.Rows(e.RowIndex).Cells(3).Value)    
        For Baris As Integer = 0 To DataGridView1.Rows.Count - 2
            DataGridView1.Rows(Baris).Cells(5).Value = DataGridView1.Rows(Baris).Cells(3).Value * DataGridView1.Rows(Baris).Cells(4).Value
        Next
        Call RumusSubTotal()
        bayar.Clear()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.BackColor = Color.Teal
        siapIsi()
        Call NomorOtomatis()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        jam.Text = Format(TimeOfDay, "HH:mm:ss")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If sisa.Text = "" Or nota.Text = "" Or total.Text = "" Or no_transaksi.Text = "" Or keterangan.Text = "" Or keterangan.Text = "" Then

            MsgBox("TransaksiKurang Lengkap Silahkan Di periksa lagi")
        Else
            If DTP1.Text = Today Then
                MsgBox("Maaf Tanggal Ambil Belum Valid")
            Else
                Call Koneksi()
                Cmd = New OleDbCommand("select*from tbl_transaksi where no_transaksi ='" & no_transaksi.Text & "'", Conn)
                Rd = Cmd.ExecuteReader
                Rd.Read()
                If Rd.HasRows Then
                    MsgBox("Maaf Nomor Transaksi sudah Ada...Silahkan Dania Tekan Tombol NEW..!!!")
                Else
                    Call Koneksi()
                    TglMyOdbc = Format(Today, "yyyy-MM-dd")
                    Dim Simpanjual As String = "insert into tbl_Transaksi values('" & no_transaksi.Text & "','" & TglMyOdbc & "','" & DTP1.Text & "','" & kode_pelanggan.Text & "','" & nota.Text & "','" & nama_pelanggan.Text & "','" & alamat.Text & "','" & telepon.Text & "','" & total.Text & "','" & bayar.Text & "','" & sisa.Text & "','" & FormMENU_UTAMA.STLabel4.Text & "','" & keterangan.Text & "') "
                    Cmd = New OleDbCommand(Simpanjual, Conn)
                    Cmd.ExecuteNonQuery()

                    For Baris As Integer = 0 To DataGridView1.Rows.Count - 2
                        Call Koneksi()
                        TglMyOdbc = Format(Today, "yyyy-MM-dd")
                        Dim SimpanDetail As String = "insert into detail_transaksi values('" & no_transaksi.Text & "','" & DataGridView1.Rows(Baris).Cells(0).Value & "','" & DataGridView1.Rows(Baris).Cells(1).Value & "','" & DataGridView1.Rows(Baris).Cells(4).Value & "','" & DataGridView1.Rows(Baris).Cells(3).Value & "','" & DataGridView1.Rows(Baris).Cells(2).Value & "','" & DataGridView1.Rows(Baris).Cells(5).Value & "')"
                        Cmd = New OleDbCommand(SimpanDetail, Conn)
                        Cmd.ExecuteNonQuery()

                        Call Koneksi()
                        Cmd = New OleDbCommand("select * from tbl_barang where kode_barang = '" & DataGridView1.Rows(Baris).Cells(0).Value & "'", Conn)
                        Rd = Cmd.ExecuteReader
                        Rd.Read()
                        Call Koneksi()
                        Dim KurangiStok2 As String = "Update TBL_barang set QTY = '" & Rd.Item("QTY") + DataGridView1.Rows(Baris).Cells(4).Value & "' where Kode_Barang='" & DataGridView1.Rows(Baris).Cells(0).Value & "'"
                        Cmd = New OleDbCommand(KurangiStok2, Conn)
                        Cmd.ExecuteNonQuery()
                    Next                 
                    PPD.Document = PD
                    PPD.ShowDialog()
                    MsgBox("Transaksi Berhasil di Simpan")
                    Call kondisiAwal()
                End If
                Call NomorOtomatis()
            End If
        End If
    End Sub

    Private Sub bayar_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles bayar.KeyPress
        If Not (e.KeyChar >= "0" And e.KeyChar <= "9" Or e.KeyChar = vbBack) Then
            e.Handled = True
        End If
        If e.KeyChar = Chr(13) Then          
            sisa.Text = Val(total.Text) - Val(bayar.Text)
            Button1.Focus()
        End If
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        FormPELANGGAN.ShowDialog()
    End Sub

    Private Sub PD_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PD.BeginPrint
        Dim pagesetup As New PageSettings
        pagesetup.PaperSize = New PaperSize("Custom", 200, 350)
        PD.DefaultPageSettings = pagesetup
    End Sub

    Private Sub PD_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PD.PrintPage
        Dim f10 As New Font("Times New Roman", 10, FontStyle.Regular)
        Dim f10b As New Font("Times New Roman", 10, FontStyle.Bold)
        Dim f14 As New Font("Times New Roman", 14, FontStyle.Bold)
        Dim f8 As New Font("Times New Roman", 8, FontStyle.Regular)
        Dim f6 As New Font("Times New Roman", 6, FontStyle.Regular)

        Dim leftmargin As Integer = PD.DefaultPageSettings.Margins.Left
        Dim centermargin As Integer = PD.DefaultPageSettings.PaperSize.Width / 2
        Dim rightmargin As Integer = PD.DefaultPageSettings.PaperSize.Width

        Dim kanan As New StringFormat
        Dim tengah As New StringFormat
        kanan.Alignment = StringAlignment.Far
        tengah.Alignment = StringAlignment.Center

        Dim garis As String
        garis = ".................................................................................................................................."
        Dim TopRight As StringFormat = New StringFormat()
        TopRight.LineAlignment = StringAlignment.Near
        TopRight.Alignment = StringAlignment.Far

        e.Graphics.DrawString("NOTA TRANSAKSI", f8, Brushes.Red, centermargin, 5, tengah)
        e.Graphics.DrawString("BUKIT LAUNDRY INDONESIA", f8, Brushes.Blue, centermargin, 18, tengah)
        e.Graphics.DrawString("TLP : 031-8889801", f8, Brushes.Black, centermargin, 30, tengah)
        e.Graphics.DrawString(garis, f8, Brushes.DarkRed, 0, 40)

        e.Graphics.DrawString("Nama Cst  : ", f8, Brushes.Black, 10, 50)
        e.Graphics.DrawString(nama_pelanggan.Text, f8, Brushes.Purple, 70, 50)

        e.Graphics.DrawString("Nota :", f8, Brushes.Black, 130, 50)
        e.Graphics.DrawString(nota.Text, f8, Brushes.Purple, 160, 50)

        e.Graphics.DrawString("Telepon : ", f8, Brushes.Black, 10, 60)
        e.Graphics.DrawString(telepon.Text, f8, Brushes.Purple, 70, 60)

        e.Graphics.DrawString("Tgl Masuk : ", f8, Brushes.Black, 10, 70)
        e.Graphics.DrawString(tanggal.Text, f8, Brushes.Purple, 70, 70)

        e.Graphics.DrawString("Tgl Ambil : ", f8, Brushes.Black, 10, 80)
        e.Graphics.DrawString(DTP1.Text, f8, Brushes.Purple, 70, 80)

        e.Graphics.DrawString("Nama Barang", f8, Brushes.Red, 10, 95)
        e.Graphics.DrawString("Qty", f8, Brushes.Red, 110, 95)      
        e.Graphics.DrawString("Subtotal", f8, Brushes.Red, 147, 95)
        e.Graphics.DrawString(garis, f8, Brushes.DarkRed, 0, 100)

        DataGridView1.AllowUserToAddRows = False
        Dim Tinggi As Integer
        For baris As Integer = 0 To DataGridView1.RowCount - 1
            Tinggi += 15
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(1).Value.ToString, f6, Brushes.Black, 10, 100 + Tinggi)
            e.Graphics.DrawString(DataGridView1.Rows(baris).Cells(4).Value.ToString, f6, Brushes.Black, 120, 100 + Tinggi)
            e.Graphics.DrawString(Format(DataGridView1.Rows(baris).Cells(5).Value, "##,##0"), f6, Brushes.Black, 160, 100 + Tinggi)       
        Next
        Tinggi = 100 + Tinggi
        jumlahsubtotal()
        e.Graphics.DrawString(garis, f10, Brushes.Black, 0, Tinggi)

        e.Graphics.DrawString("Total   " & Format(harga, "##,##0"), f8, Brushes.Black, 200, 15 + Tinggi, kanan)
      
        e.Graphics.DrawString("Bayar ", f8, Brushes.Black, 160, 30 + Tinggi, kanan)
        e.Graphics.DrawString(bayar.Text, f8, Brushes.Black, 200, 30 + Tinggi, kanan)

        e.Graphics.DrawString("Sisa ", f8, Brushes.Black, 160, 45 + Tinggi, kanan)
        e.Graphics.DrawString(sisa.Text, f8, Brushes.Black, 200, 45 + Tinggi, kanan)

        e.Graphics.DrawString("~~~~ Terima Kasih ~~~~", f8, Brushes.Blue, centermargin, 250, tengah)

    End Sub
    Sub jumlahsubtotal()
        Dim hitung As Integer = 0
        For baris As Integer = 0 To DataGridView1.RowCount - 1
            hitung = hitung + DataGridView1.Rows(baris).Cells(5).Value
        Next
        harga = hitung
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Call Koneksi()
        Da = New OleDbDataAdapter("select * From TBL_BARANG where NAMA_BARANG like '%" & TextBox1.Text & "%'", Conn)
        Ds = New DataSet
        Da.Fill(Ds)
        DGV2.DataSource = Ds.Tables(0)
        DGV2.ReadOnly = True
        If TextBox1.Text = "" Then
            Label11.Visible = True
        Else
            Label11.Visible = False
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        animaten(Me, False)
        Me.Close()
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        FormDATA_BARANG.ShowDialog()
    End Sub
End Class