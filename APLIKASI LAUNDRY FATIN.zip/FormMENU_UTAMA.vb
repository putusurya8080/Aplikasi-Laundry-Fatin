﻿Public Class FormMENU_UTAMA

    Private Sub DATAADMINToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATAADMINToolStripMenuItem.Click
        FormAdmin.ShowDialog()
    End Sub
    Private Sub FormMENU_UTAMA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Terkunci()
        STLabel8.Text = Format(TimeOfDay, "HH:mm:ss")
        STLabel10.Text = Today
        StatusStrip1.ForeColor = Color.Yellow      
        MenuStrip1.BackColor = Color.Turquoise
        MenuStrip1.ForeColor = Color.Red
    End Sub
    Sub Terkunci()
        LoginToolStripMenuItem.Enabled = True
        LogoutToolStripMenuItem.Enabled = False
        MasterToolStripMenuItem.Enabled = False
        TransaksiToolStripMenuItem.Enabled = False
        LaporanToolStripMenuItem.Enabled = False
        UtilityToolStripMenuItem.Enabled = False
     
    End Sub

    Private Sub LOGINToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LOGINToolStripMenuItem.Click
        FormLogin.ShowDialog()
    End Sub

    Private Sub KELUARToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KELUARToolStripMenuItem.Click
        End
    End Sub

    Private Sub LOGOUTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LOGOUTToolStripMenuItem.Click
        Call Terkunci()
    End Sub

    Private Sub DATABARANGToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATABARANGToolStripMenuItem.Click
        FormDATA_BARANG.ShowDialog()
    End Sub

    Private Sub TRANSAKSIPENERIMAANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TRANSAKSIPENERIMAANToolStripMenuItem.Click
        FormTRANSAKSI.ShowDialog()
    End Sub

    Private Sub DATAPELANGGANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATAPELANGGANToolStripMenuItem.Click
        FormPELANGGAN.ShowDialog()
    End Sub

    Private Sub TRANSAKSIPENGAMBILANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TRANSAKSIPENGAMBILANToolStripMenuItem.Click
        FormPENGEMBALIAN.ShowDialog()
    End Sub

    Private Sub PENERIMAANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENERIMAANToolStripMenuItem.Click
        FormDaftar_Transaksi.ShowDialog()
    End Sub

    Private Sub PENGAMBILANToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PENGAMBILANToolStripMenuItem.Click
        FormDaftar_Kembali.ShowDialog()
    End Sub
    Dim i As Integer
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        I = I + 1
        If I = 2 Then
            I = 0
        End If
        If I Mod 2 = 0 Then
            Label1.Visible = True
            Label2.Visible = False
        Else
            Label1.Visible = False
            Label2.Visible = True
        End If
    End Sub
End Class
